jue 13 mar 2025 12:19:51 -04
jorge-andrade
6.8.0-52-generic
PRETTY_NAME="Ubuntu 24.04.1 LTS"
NAME="Ubuntu"
Este es mi documento de la Tarea 4.
