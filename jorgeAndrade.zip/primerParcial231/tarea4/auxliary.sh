
date > readmeExam.md

whoami >> readmeExam.md

uname -r >> readmeExam.md

grep -E '^(NAME|PRETTY_NAME)=' /etc/os-release >> readmeExam.md

echo "Este es mi documento de la Tarea 4." >> readmeExam.md

